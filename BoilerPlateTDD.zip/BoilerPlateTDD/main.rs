struct Config {
    verbose: bool,
    testing: bool,
    drawing: bool,
}

fn main() {
    let config = Config {
        verbose: true,
        testing: true,
        drawing: false,
    };

    if config.verbose {
        println!("verbose {:?}", config.verbose);
        println!("testing {:?}", config.testing);
        println!("drawing {:?}", config.drawing);
    };
}

